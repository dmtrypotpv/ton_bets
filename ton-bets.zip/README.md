# TON Bets
Децентрализованное мини-приложение ставок в TON.

## Структура
- contracts/ — смарт-контракты на Tact (Factory + Event)
- frontend/ — веб-интерфейс (index.html)

## Запуск
1. Скомпилировать контракты через Tact.
2. Задеплоить Factory и создавать события.
3. Открыть frontend/index.html как Telegram WebApp.
